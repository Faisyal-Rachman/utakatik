<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Login with Facebook in CodeIgniter</title>
</head>
<body><br><br><br>
      <label>nama : <?php echo $name;?></label><br>
	<a href="<?=$authUrl?>"><img src="<?=base_url()?>assets/imgs/flogin.png" alt=""/></a>
</body>
</html>