
<br><br><br><br>
<div class="container text-center">
  <h2>Login codeigniter with facebook </h2>
  <label>nama : <?php echo $name;?></label><br>
  <label>Email : <?php echo $email;?></label>
  <img src="<?php echo $gambar;?>" class="mx-auto d-block" style="width:10%"> 
<br>
<a href="logout" class="btn btn-primary">Sign out</a>
</div>
